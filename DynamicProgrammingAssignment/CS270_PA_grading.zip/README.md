### CSCI 270 Fall 2018 Programming Assignment
- Put your source code in the same folder as `cs270_checker.py`. Its filename should be `grid.cpp` / `grid.c` / `grid.java` / `grid.py`.
> For Java, if your main class is not named `grid`, rename the file and class.
- Run `python cs270_checker.py` (or `python3 cs270_checker.py`) from terminal.
- Your report should be saved in `result.txt`.
### Important
- This script is written for Linux VM, although it might also work on MacOS.
- If you want to request a regrade because of I/O issues or syntax errors, make sure your code runs correctly with `cs270_checker.py`.
- We tried to fix common I/O issues and syntax errors when grading, so please request regrade only after your score is published.
/*
	CSCI 270 Fall 2018
	Programming Assignment
	Standard Solution 3
*/
#include <iostream>
#include <vector>
#include <string>

using namespace std;
const int inf = 1000000000;

int dp[110][110][3];

/*
	Some special properties of this problem make it possible to store only 3
	states in each tile instead of 4. It's OK if you cannot figure out the way
	to prove the correctness of this algorithm.
*/
int solve(int N, vector<vector<string> > G) {
	for (int i=0; i<=N; i++)
		for (int j=0; j<3; j++)
			dp[N][i][j] = dp[i][N][j] = inf;
	dp[N][N-1][0] = dp[N][N-1][1] = dp[N][N-1][2] = 1;
	for (int i=N-1; i>=0; i--) {
		for (int j=N-1; j>=0; j--) {
			if (G[i][j] == "D") {
				dp[i][j][0] = min(dp[i+1][j][1], dp[i][j+1][1]);
				dp[i][j][1] = dp[i][j][0]; // double
				dp[i][j][2] = min(dp[i+1][j][1]+dp[i+1][j][2]-dp[i+1][j][0], dp[i][j+1][1]+dp[i][j+1][2]-dp[i][j+1][0]);
			} else if (G[i][j] == "P") {
				dp[i][j][0] = min(dp[i+1][j][2], dp[i][j+1][2]);
				dp[i][j][1] = min(dp[i+1][j][2]+dp[i+1][j][1]-dp[i+1][j][0], dp[i][j+1][2]+dp[i][j+1][1]-dp[i][j+1][0]);
				dp[i][j][2] = dp[i][j][0]; // prevent
			} else {
				int val = stoi(G[i][j]);
				if (val < 0) {
					dp[i][j][0] = min(dp[i+1][j][0], dp[i][j+1][0]) - val;
					dp[i][j][1] = min(dp[i+1][j][1], dp[i][j+1][1]) - val;
					dp[i][j][2] = min(dp[i+1][j][0], dp[i][j+1][0]);
				} else {
					dp[i][j][0] = min(dp[i+1][j][0], dp[i][j+1][0]) - val;
					dp[i][j][1] = min(dp[i+1][j][0], dp[i][j+1][0]) - val * 2;
					dp[i][j][2] = min(dp[i+1][j][2], dp[i][j+1][2]) - val;
				}
			}
			for (int k=0; k<3; k++) {
				dp[i][j][k] = max(1, dp[i][j][k]);
			}
		}
	}
	return dp[0][0][0];
}

int main(int argc, char **argv) {
	int N;
	vector<vector<string> > G;
	cin >> N;
	G.resize(N);
	for (int i=0; i<N; i++) {
		for (int j=0; j<N; j++) {
			string tmp;
			cin >> tmp;
			G[i].push_back(tmp);
		}
	}
	cout << solve(N, G) << endl;
	return 0;
}

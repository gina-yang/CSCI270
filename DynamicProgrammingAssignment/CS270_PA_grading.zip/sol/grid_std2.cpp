/*
	CSCI 270 Fall 2018
	Programming Assignment
	Standard Solution 2
*/
#include <iostream>
#include <vector>
#include <string>

using namespace std;
const int inf = 1000000000;

struct arraymanager{
	vector<int> v;
	int N;
	int hp;
	int out;
	arraymanager(int _N, int _hp): v(vector<int>(_N*_N*4, -inf)), N(_N), hp(_hp), out(-inf) {}
	int &operator () (int i, int j, int k, int l) {
		if (i == 0 && j < 0 && k == 0 && l == 0)
			return hp; // Return Brian's initial hp
		if (i < 0 || j < 0)
			return out; // Out of bounds, invalid move
		return v[i*N*4+j*4+k*2+l];
	}
};

int mx(int a, int b=-inf, int c=-inf, int d=-inf) {
	return max(max(a, b), max(c, d)); // max of 4 elements
}

// Doing a dynamic programming from top left to bottom right.
bool check(int N, int hp, vector<vector<string> > G) {
	arraymanager dp(N, hp);
	for (int i=0; i<N; i++) {
		for (int j=0; j<N; j++) {
			if (G[i][j] == "P") {
				// gain effect: prevent next damage
				for (int k=0; k<=1; k++) {
					dp(i, j, 1, k) = mx(dp(i-1, j, 1, k), dp(i-1, j, 0, k), dp(i, j-1, 1, k), dp(i, j-1, 0, k));
				}
			} else if (G[i][j] == "D") {
				// gain effect: double next healing effect
				for (int k=0; k<=1; k++) {
					dp(i, j, k, 1) = mx(dp(i-1, j, k, 0), dp(i-1, j, k, 1), dp(i, j-1, k, 0), dp(i, j-1, k, 1));
				}
			} else {
				int val = stoi(G[i][j]);
				if (val > 0) {
					// heal
					for (int k=0; k<=1; k++) {
						dp(i, j, k, 0) = mx(dp(i-1, j, k, 0) + val, dp(i-1, j, k, 1) + val*2, dp(i, j-1, k, 0) + val, dp(i, j-1, k, 1) + val*2);
					}
				} else {
					// damage dealt
					for (int k=0; k<=1; k++) {
						dp(i, j, 0, k) = mx(dp(i-1, j, 0, k) + val, dp(i-1, j, 1, k), dp(i, j-1, 0, k) + val, dp(i, j-1, 1, k));
					}
				}
			}
			// disallow hp <= 0 on the halfway
			for (int k=0; k<=1; k++)
				for (int l=0; l<=1; l++)
					if (dp(i, j, k, l) <= 0)
						dp(i, j, k, l) = -inf;
		}
	}
	// return true if the bottom right corner is accessible
	return mx(dp(N-1, N-1, 0, 0), dp(N-1, N-1, 0, 1), dp(N-1, N-1, 1, 0), dp(N-1, N-1, 1, 1)) > 0;
}

int solve(int N, vector<vector<string> > G) {
	int l = 1, r = inf;
	// binary search on hp value
	while (r > l) {
		int mid = (l+r) / 2;
		if (check(N, mid, G))
			r = mid;
		else
			l = mid+1;
	}
	return l;
}

int main(int argc, char **argv) {
	int N;
	vector<vector<string> > G;
	cin >> N;
	G.resize(N);
	for (int i=0; i<N; i++) {
		for (int j=0; j<N; j++) {
			string tmp;
			cin >> tmp;
			G[i].push_back(tmp);
		}
	}
	cout << solve(N, G) << endl;
	return 0;
}

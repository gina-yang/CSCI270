/*
	CSCI 270 Fall 2018
	Programming Assignment
	Partial Credit Solution (80%)
*/
#include <iostream>
#include <vector>
#include <string>

using namespace std;
const int inf = 1000000000;

/*
	dp[i][j] is the minimum amount of life that Brian needs to travel from
	G[i][j] to G[N-1][N-1].
	Base case: dp[N][N-1] = 1, and other dp values are all infinity, which
		means we need 1 hp to complete the task and we cannot escape outside
		the grid from tiles other than G[N-1][N-1].
*/
int solve(int N, vector<vector<string> > G) {
	vector<vector<int> > dp(N+1, vector<int>(N+1, inf));
	dp[N][N-1] = 1;
	for (int i=N-1; i>=0; i--) {
		for (int j=N-1; j>=0; j--) {
			int val = stoi(G[i][j]);
			dp[i][j] = max(1, min(dp[i+1][j], dp[i][j+1]) - val);
			/*
				The optimal solution is independent of what we did before.
				We should choose the grid requiring less amount of hp as our
				next step. In this case, since we will gain / lose |val| hp
				on current grid, we need to subtract this amount.
				After subtracting, the result might be negative. Notice that
				Brian must have at least 1 hp.
			*/
		}
	}
	return dp[0][0];
}

int main(int argc, char **argv) {
	int N;
	vector<vector<string> > G;
	cin >> N;
	G.resize(N);
	for (int i=0; i<N; i++) {
		for (int j=0; j<N; j++) {
			string tmp;
			cin >> tmp;
			G[i].push_back(tmp);
		}
	}
	cout << solve(N, G) << endl;
	return 0;
}

/*
	CSCI 270 Fall 2018
	Programming Assignment
	Standard Solution 1
*/
#include <iostream>
#include <vector>
#include <string>

using namespace std;
const int inf = 1000000000;

// This struct is only used to simulate a 4d array and handle base cases.
// You can create a 4d array instead, and initialize correct values for edge cases.
struct arraymanager{
	vector<int> v;
	int N;
	int hp;
	int out;
	arraymanager(int _N): v(vector<int>(_N*_N*4, inf)), N(_N), hp(1), out(inf) {}
	int &operator () (int i, int j, int k, int l) {
		if (i == N-1 && j == N)
			return hp; // Brian needs 1 hp to complete the task
		if (i >= N || j >= N)
			return out; // Out of bounds, invalid move
		return v[i*N*4+j*4+k*2+l];
	}
};

/*
	Please refer to grid_partial.cpp first.
	Based on that, we added two extra variables in our state: dp[i][j][k][l].
	k is a 0/1 bit indicating whether Brian has a "P" buff,
	while l is a 0/1 bit indicating whether Brian has a "D" buff.
	So the value of dp[i][j][k][l] is the minimum amount of life Brian needs
	to travel from G[i][j] to G[N-1][N-1], given that he has/does not have a
	"P"/"D" buff when entering G[i][j]. (known from the value of k and l)
*/
int solve(int N, vector<vector<string> > G) {
	arraymanager dp(N);
	for (int i=N-1; i>=0; i--) {
		for (int j=N-1; j>=0; j--) {
			if (G[i][j] == "P") {
				for (int k=0; k<=1; k++) {
					dp(i, j, 0, k) = min(dp(i+1, j, 1, k), dp(i, j+1, 1, k));
					dp(i, j, 1, k) = dp(i, j, 0, k);
					/*
						Brian will gain a "P" buff on current tile, so we should
						always choose dp[i'][j'][1][k'] as the next step, whether
						Brian has a "P" buff when entering the tile or not.
					*/
				}
			} else if (G[i][j] == "D") {
				for (int k=0; k<=1; k++) {
					dp(i, j, k, 0) = min(dp(i+1, j, k, 1), dp(i, j+1, k, 1));
					dp(i, j, k, 1) = dp(i, j, k, 0);
					// Similar to "P"
				}
			} else {
				int val = stoi(G[i][j]);
				if (val > 0) {
					for (int k=0; k<=1; k++) {
						dp(i, j, k, 1) = max(1, min(dp(i+1, j, k, 0), dp(i, j+1, k, 0)) - val*2);
						dp(i, j, k, 0) = max(1, min(dp(i+1, j, k, 0), dp(i, j+1, k, 0)) - val);
						/*
							If Brian does not have a "D" buff, the transition
							stays the same as the partial solution; otherwise,
							the buff will be used and Brian needs twice less
							hp when entering the tile in order to complete his
							task.
						*/
					}
				} else {
					for (int k=0; k<=1; k++) {
						dp(i, j, 0, k) = max(1, min(dp(i+1, j, 0, k), dp(i, j+1, 0, k)) - val);
						dp(i, j, 1, k) = max(1, min(dp(i+1, j, 0, k), dp(i, j+1, 0, k)));
						// Similar to "D"
					}
				}
			}
		}
	}
	// Brian does not have any buff at the very beginning.
	return dp(0, 0, 0, 0);
}

int main(int argc, char **argv) {
	int N;
	vector<vector<string> > G;
	cin >> N;
	G.resize(N);
	for (int i=0; i<N; i++) {
		for (int j=0; j<N; j++) {
			string tmp;
			cin >> tmp;
			G[i].push_back(tmp);
		}
	}
	cout << solve(N, G) << endl;
	return 0;
}

################### grid ####################
# CSCI 270 Fall 2018 Programming Assignment #
#############################################

# The script cannot run in Windows
import subprocess, threading
import os, signal, sys

python_executable = 'python'
# if code failed to run in python2 environment, try 'python3'

file_name = 'grid'
grid_output = 'result.txt'
# The output is saved in results.txt

cpp_compile_flags = '-std=c++11'
c_compile_flags = '-lm -std=c11'
java_compile_flags = ''

time_limit = 1.5

class Command:
	def __init__(self):
		self.process = None

	def run(self, cmd, input=None, output=None, timeout=60):
		def target():
			if input != None:
				with open(input, "r") as ifile, open(output, "w") as ofile:
					self.process = subprocess.Popen(cmd, shell=True, stdin=ifile, stdout=ofile, preexec_fn=os.setsid)
			else:
				self.process = subprocess.Popen(cmd, shell=True, preexec_fn=os.setsid)
			self.process.communicate()

		thread = threading.Thread(target=target)
		thread.start()

		thread.join(timeout)
		if thread.is_alive():
			os.killpg(self.process.pid, signal.SIGTERM)
			thread.join()
			return (1, "Time Limit Exceeded")
		if self.process.returncode == 0:
			return (0, "Program exited with return value 0")
		return (2, "Runtime Error")

cs = Command()

def run_tests(cmd):
	count = 0
	pass_count = 0
	tle_count = 0
	re_count = 0
	wa_count = 0
	fres = open(grid_output, "w")
	for file in os.listdir("./in/"):
		path = file.split('.')
		ext = path[-1]
		if ext != "in":
			continue
		count += 1
		name = ".".join(path[0:-1])
		print(count, "Running: " + name)
		(res, desc) = cs.run(cmd, "./in/" + name + ".in", "./out/" + name + ".out", time_limit)
		if res == 1:
			tle_count += 1
			fres.write(name + ": Time Limit Exceeded (Terminated)\n")
		elif res == 2:
			re_count += 1
			fres.write(name + ": Runtime Error (Return value is not 0)\n")
		else:
			fin = open("./out/" + name + ".out", "r")
			output = fin.readline()
			fin.close()
			fin = open("./ans/" + name + ".ans", "r")
			answer = fin.readline()
			fin.close()
			try:
				output = int(output)
				answer = int(answer)
				if output == answer:
					pass_count += 1
					fres.write(name + ": Correct Answer!\n")
				else:
					wa_count += 1
					fres.write(name + ": Expect " + str(answer) + ", read " + str(output) + "\n")
			except:
				wa_count += 1
				fres.write(name + ": Unrecognized Output Format\n")
	fres.write("=========== Summary ==========\n")
	fres.write("Passed " + str(pass_count) + " / " + str(count) + " test cases.\n")
	if (pass_count == count):
		fres.write("All test cases passed: Accepted!\n")
	fres.close()
	print("Passed " + str(pass_count) + " / " + str(count) + " test cases.")
	print("Results saved to " + grid_output)

def run_grid():
	if not os.path.exists("./out/"):
		os.mkdir("./out/")

	if os.path.exists("./" + file_name + ".py"):
		print("Found python solution, start grading...")
		run_tests(python_executable + " ./" + file_name + ".py")
		return
	elif os.path.exists("./" + file_name + ".cpp"):
		print("Found C++ solution, compiling...")
		(res, desc) = cs.run("g++ " + file_name + ".cpp " + "-o " + file_name + " " + cpp_compile_flags)
		if res != 0:
			print("Failed to compile source code: " + desc)
			return
	elif os.path.exists("./" + file_name + ".c"):
		print("Found C solution, compiling...")
		(res, desc) = cs.run("gcc " + file_name + ".c " + "-o " + file_name + " " + c_compile_flags)
		if res != 0:
			print("Failed to compile source code: " + desc)
			return
	elif os.path.exists("./" + file_name + ".java"):
		print("Found Java solution, compiling...")
		(res, desc) = cs.run("javac " + file_name + ".java " + java_compile_flags)
		if res != 0:
			print("Failed to compile source code: " + desc)
			return
		run_tests("java " + file_name)
		return
	run_tests("./" + file_name)
	return

run_grid()
